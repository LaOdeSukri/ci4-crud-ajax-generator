# CI4 Generic CRUD Generator (JSON-driven)

## Routes (add to app/Config/Routes.php)
$routes->get('backend/(:any)','Backend\CrudController::index/$1');
$routes->get('backend/(:any)/json','Backend\CrudController::json/$1');
$routes->post('backend/(:any)/save','Backend\CrudController::save/$1');
$routes->post('backend/(:any)/delete/(:num)','Backend\CrudController::delete/$1/$2');
$routes->get('backend/(:any)/export/excel','Backend\CrudController::exportExcel/$1');
$routes->get('backend/(:any)/export/pdf','Backend\CrudController::exportPDF/$1');

## Usage
- Place your table definition JSON in `writable/uploads/json/<name>.json`
- Visit `/backend/<name>.json` in browser (e.g., `/backend/users.json`)
- Mode is configured via `crud_mode`: `server` or `ajax`

## Dependencies
composer require phpoffice/phpspreadsheet dompdf/dompdf
